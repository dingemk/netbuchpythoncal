Thank you to everybody that has contributed to the microbit-fs project:

Carlos Pereira Atencio (carlos@microbit.org)
Ross Lowe (ross@microbit.org)
Matt Hillsdon (matt.hillsdon@microbit.org)
