Thanks for looking here! We'd love your help. The micro:bit project is only
possible through contributions of companies and individuals around the world.

This project is managed [in this GitHub project](https://github.com/microbit-foundation/microbit-fs), and the best way to contribute
is to jump in and fix/file issues.

If you're interested in working on any of these items, please file an issue
and mention @microbit-carlos.
